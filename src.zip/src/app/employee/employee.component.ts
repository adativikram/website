import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

Myname="vikram";

  EmployeeTable=[
    {'empName':"vikram",'empGender':"Male",'empDept':"tech"},
    {'empName':"varsha",'empGender':"Female",'empDept':"core"},
    {'empName':"kamini",'empGender':"Female",'empDept':"core"},
    {'empName':"prabhusai",'empGender':"Male",'empDept':"tech"}
  ]
getTotalEmployee():number{
  return this.EmployeeTable.length;
}
getMaleCount():number{
  return this.EmployeeTable.filter(e=>e.empGender==="Male").length;
}

getFemaleCount():number{
  return this.EmployeeTable.filter(e=>e.empGender==="Female").length;
}





  ngOnInit() {
  }

}
