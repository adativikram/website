import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employee-data',
  templateUrl: './employee-data.component.html',
  styleUrls: ['./employee-data.component.css']
})
export class EmployeeDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input()
  total:number;
  @Input()
  male:number;
  @Input()
  female:number;

selectedEmployee:String='total';

// @Output()
// OnSelectionOfRatioButton:EventEmitter<String>=new EventEmitter<String>();

// OnSelectionRatioButton(){
//   this.OnSelectionOfRatioButton.emit(this.selectedEmployee);
// }

}
  

