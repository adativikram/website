import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingComponentsComponent } from './binding-components.component';

describe('BindingComponentsComponent', () => {
  let component: BindingComponentsComponent;
  let fixture: ComponentFixture<BindingComponentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BindingComponentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BindingComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
