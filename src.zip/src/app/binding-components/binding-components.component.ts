import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding-components',
  templateUrl:
   './binding-components.component.html',

  styleUrls: ['./binding-components.component.css']
})

export class BindingComponentsComponent implements OnInit {

  
bankAdd:String;
name:String;
myId:String="vikram";
bank:String="icici";

  display():String{
this.bankAdd="hyderabad";
return this.bankAdd;
  }


  CustomerList=[
    {'name':"Prabhusai",'type':"Premium"},
    {'name':"Koushik",'type':"waste"},
    {'name':"vikram",'type':"above Premium"}
  ]


  constructor() { }

  ngOnInit() {
  }

}
