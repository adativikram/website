import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MobileAppComponentsComponent } from './mobile-app-components.component';

describe('MobileAppComponentsComponent', () => {
  let component: MobileAppComponentsComponent;
  let fixture: ComponentFixture<MobileAppComponentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MobileAppComponentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobileAppComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
