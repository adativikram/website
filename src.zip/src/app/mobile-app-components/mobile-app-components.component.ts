import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-app-components',
  templateUrl: './mobile-app-components.component.html',
  styleUrls: ['./mobile-app-components.component.css']
})
export class MobileAppComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
