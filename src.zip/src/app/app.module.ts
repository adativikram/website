import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MobileAppComponentsComponent } from './mobile-app-components/mobile-app-components.component';
import { BindingComponentsComponent } from './binding-components/binding-components.component';
import {EmployeeComponent} from './employee/employee.component';
import { FormsModule } from '@angular/forms';
import { EmployeeDataComponent } from './employee-data/employee-data.component';
import { MydirectiveDirective } from './mydirective.directive';

@NgModule({
  declarations: [
    AppComponent,
    MobileAppComponentsComponent,
    BindingComponentsComponent,
    EmployeeComponent,
    EmployeeDataComponent,
    MydirectiveDirective

  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
